Functions and nested loops
