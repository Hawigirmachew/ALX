More on pointers, arrays and strings
