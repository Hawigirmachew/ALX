#include "main.h"
/**
 * mul - multiplication of two numbers
 * @a: takes integer
 * @b: takes integer
 * Return: Alwats 1
 */
int mul(int a, int b)
{
	return (a * b);
}
