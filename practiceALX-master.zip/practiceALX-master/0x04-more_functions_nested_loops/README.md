More functions nested loops
