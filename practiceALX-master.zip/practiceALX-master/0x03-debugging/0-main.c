#include "main.h"
/**
 * main -entry block
 *Retturn : always 0
 */
int main(void)
{
int i;

int 0;

positive_or_negative(i);

return (0);

}

